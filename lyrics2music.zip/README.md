# 🎵 Lyrics-to-Music Generator (Hindi, Devotional, Romantic)

This app uses AI to generate full songs from lyrics in Indian languages.

🔧 Powered by:
- 🗣 Bark (for singing voice)
- 🎼 MusicGen (for background music)
- 🎛️ Streamlit (for user interface)

Try entering Hindi lyrics, select a voice type (child, old, soft female), and generate a full song!